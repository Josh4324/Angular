export class LoginData {
  email: string;
  password: string;
  projectName: string;
}
