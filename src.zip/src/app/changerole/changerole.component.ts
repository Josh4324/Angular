import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-changerole',
  templateUrl: './changerole.component.html',
  styleUrls: ['./changerole.component.scss']
})
export class ChangeroleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
