import { LoginData } from './loginData';

describe('LoginData', () => {
  it('should create an instance', () => {
    expect(new LoginData()).toBeTruthy();
  });
});
