export class Scrumuser {
    fullname: string;
    email: string;
    password: string;
    type: string;
    projname: string;
}
